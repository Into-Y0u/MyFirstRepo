CREATE TABLE booking (
bookingid int,
guestID int ,
resortID int ,
cabinID int ,
fromdate Date ,
todate Date ,
adultCount int , 
childCount int ,
petcount int , 
totalcharge int , 
PRIMARY KEY (bookingid)
);